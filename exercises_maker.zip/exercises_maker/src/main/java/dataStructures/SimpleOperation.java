package dataStructures;


import lombok.Getter;

import java.util.Objects;

@Getter
public class SimpleOperation {

    private String operator;

    private Integer left;

    private Integer right;
}
